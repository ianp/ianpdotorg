package com.example.demo;

public final class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}

